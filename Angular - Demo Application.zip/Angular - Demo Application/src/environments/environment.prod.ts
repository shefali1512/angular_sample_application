export const environment = {
  production: true,
  SPRING_SERVER_URL: 'https://springapi.Sample_application.com/',
  AWS_COGNITO_URL: 'https://api.Sample_application.com'
};
