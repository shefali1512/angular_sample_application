import { Component } from '@angular/core';
import { Router } from '@angular/router';

@Component({
    selector: 'app-root',
    templateUrl: './app.component.html'
})

export class AppComponent {
    searchVisibleemp: boolean = false;
    searchVisiblefree: boolean = false;
    searchVisibleagency: boolean = false;
    searchVisibleent: boolean = false;
    constructor(private router: Router){

    }

    ngOnInit(){
        // this.router.navigateByUrl('authentication/login');
    }
}
