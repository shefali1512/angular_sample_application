import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { NzModalService } from 'ng-zorro-antd/modal';
import { NgxSpinnerService } from 'ngx-spinner';
import { AuthenticationService } from 'src/app/services/authentication.service';
import { PasswordStrengthValidator } from '../password-strength.validators';
@Component({
    selector: 'app-reset-password',
    templateUrl: './reset-password.component.html',
    styleUrls: ['./reset-password.component.css']
})
export class ResetPasswordComponent implements OnInit {

    resetPassForm: FormGroup;

    userDetails:any;

    userID:any;

    email: string;

    hide = true;

    hide1 = true;

    verifCode: any;

    constructor(private fb: FormBuilder,  private spinner: NgxSpinnerService, private modalService: NzModalService, private router: Router, private authService: AuthenticationService) { }

    ngOnInit(): void {
        this.userDetails = JSON.parse(sessionStorage.getItem('userDetails'));
        this.email = sessionStorage.getItem('email');
        if (!this.email) {
            this.errorBackToForgPwd("Email not found. Enter again.")
        }

        this.resetPassForm = this.fb.group({
            newPassword: [null, Validators.compose([Validators.required, Validators.minLength(8), PasswordStrengthValidator])],
            confirmPassword: [null, Validators.compose([Validators.required, Validators.minLength(8), PasswordStrengthValidator, this.confirmationValidator])],
            otp1: [null, [Validators.required]],
            otp2: [null, [Validators.required]],
            otp3: [null, [Validators.required]],
            otp4: [null, [Validators.required]],
            otp5: [null, [Validators.required]],
            otp6: [null, [Validators.required]],
        });
    }
    keyDown() {
        var e = window.event || e;
        var key = e.keyCode;
        //space pressed
        if (key == 32) { //space
            e.preventDefault();
        }
    }

    onPaste(event: ClipboardEvent) {
        
        let clipboardData = event.clipboardData;
        let pastedText = clipboardData.getData('text');
      }
    confirmationValidator = (control: FormControl): { [s: string]: boolean } => {
        if (!control.value) {
            return { required: true };
        } else if (control.value !== this.resetPassForm.controls.newPassword.value) {
            return { confirm: true, error: true };
        }
    }

    updateConfirmValidator(): void {
        Promise.resolve().then(() => this.resetPassForm.controls.confirmPassword.updateValueAndValidity());
    }

    success(): void {
        const modal = this.modalService.success({
            nzTitle: 'Password has been reset successfully!',
            nzOnOk: () => this.goToSignIn()
        });
      
    }

    errorBackToForgPwd(errorMsg: string): void {
        const modal = this.modalService.error({
            nzTitle: 'Something went wrong',
            nzContent: errorMsg,
            nzOnOk: () => this.goToForgotPassword()
        });
    }

    errorOTP(errorMsg: string): void {
        const modal = this.modalService.error({
            nzTitle: 'Something went wrong',
            nzContent: errorMsg,
        });
        
    }

    error(errorMsg: string): void {
        const modal = this.modalService.error({
            nzTitle: 'Something went wrong',
            nzContent: errorMsg,
            nzOnOk: () => this.goToSignIn()
        });
    }

    goToSignIn() {
        this.router.navigateByUrl('');
    }

    goToForgotPassword() {
        this.router.navigateByUrl('forget-password');
    }
    submitForm() {
        for (const i in this.resetPassForm.controls) {
            this.resetPassForm.controls[i].markAsDirty();
            this.resetPassForm.controls[i].updateValueAndValidity();
        }
    }

    resendOTP() {
        if (this.email) {
            let data = {
                'email': this.email
            }
            this.authService.resetPassword(data).then((res: any) => {
                if (res.status == "SUCCESS") {
                    const modal = this.modalService.success({
                        nzTitle: 'OTP has been sent!',
                    });
                }
                else {
                    this.error(res.response.message);
                }
            });
            this.resetPassForm.reset();
        }
        else {
            this.errorBackToForgPwd("Email not found. Enter again.");
        }
    }

    resetPassword() {
        this.verifCode = (this.resetPassForm.get('otp1').value) +
            (this.resetPassForm.get('otp2').value) +
            (this.resetPassForm.get('otp3').value) +
            (this.resetPassForm.get('otp4').value) +
            (this.resetPassForm.get('otp5').value) +
            (this.resetPassForm.get('otp6').value);

        let data = {
            "email": this.email,
            "code": this.verifCode,
            "password": this.resetPassForm.get('confirmPassword').value
        }
        this.spinner.show();
        this.authService.sendResetPwdDetails(data)
            .then((res: any) => {
                if (res.status == "SUCCESS") {
                    this.resetPasswordDB();
                    this.spinner.hide();
                    this.success();
                }
                else if (res.status == "ERROR") {
                    this.spinner.hide();
                    this.errorOTP(res.response.message);
                    this.resetPassForm.get('otp1').setValue("");
                    this.resetPassForm.get('otp2').setValue("");
                    this.resetPassForm.get('otp3').setValue("");
                    this.resetPassForm.get('otp4').setValue("");
                    this.resetPassForm.get('otp5').setValue("");
                    this.resetPassForm.get('otp6').setValue("");
                }
            })
    }

        resetPasswordDB() {
        this.spinner.show();
        this.authService.resetPasswordInfo(this.email, this.resetPassForm.get('confirmPassword').value,)
            .then((res: any) => {
                if (res.status == "SUCCESS") {
                    this.spinner.hide();
                    this.success();
                }
                else if (res.status == "ERROR") {
                    this.spinner.hide();
                    this.errorOTP(res.response.message);
                }
            })
    }


    keytab(event,id) {
        if(event.keyCode != 8){
        let nextid = id + 1;
        document.getElementById("otp" + nextid).focus();
        }
        else{
        let previd = id - 1;
        document.getElementById("otp" + previd).focus();
        } 
        
    }

    numberOnly(event): boolean {
        const charCode = event.which ? event.which : event.keyCode;
        if (charCode > 31 && (charCode < 48 || charCode > 57)) {
            return false;
        }
        return true;
    }
}
