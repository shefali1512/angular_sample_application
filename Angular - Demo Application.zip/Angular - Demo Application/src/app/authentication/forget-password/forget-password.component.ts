import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { NzModalService } from 'ng-zorro-antd/modal';
import { NgxSpinnerService } from 'ngx-spinner';
import { AuthenticationService } from 'src/app/services/authentication.service';
@Component({
    selector: 'app-forget-password',
    templateUrl: './forget-password.component.html',
    styleUrls: ['./forget-password.component.css']
})
export class ForgetPasswordComponent implements OnInit {

    forgetpassForm: FormGroup;

    email: any;

    constructor(private fb: FormBuilder, private spinner: NgxSpinnerService, private modalService: NzModalService, private router: Router, private authService: AuthenticationService) { }

    ngOnInit(): void {
        this.forgetpassForm = this.fb.group({
            email: ['', Validators.compose([Validators.email, Validators.required, Validators.pattern(/^(([^<>()[\]\\.,;:\s@\"]+(\.[^<>()[\]\\.,;:\s@\"]+)*)|(\".+\"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/)])]
        });
    }

    keyDown() {
        var e = window.event || e;
        var key = e.keyCode;
        //space pressed
        if (key == 32) { //space
            e.preventDefault();
        }
    }



    onPaste(event: ClipboardEvent) {
        let clipboardData = event.clipboardData;
        let pastedText = clipboardData.getData('text');
        let trueValue = pastedText.replace(/\s/g, "");

        setTimeout(() => {
            this.forgetpassForm.get('email').setValue("");
            this.forgetpassForm.get('email').patchValue(trueValue);
        }, 1);
    }


    success(): void {
        const modal = this.modalService.success({
            nzTitle: 'OTP has been sent successfully.',
            nzContent: 'Please check your mail Box.',
            nzOnOk: () => this.submitForm()
        });
    }

    error(errorMsg: string): void {
        const modal = this.modalService.error({
            nzTitle: 'Something went wrong.',
            nzContent: errorMsg
        });
    }

    sendEmailforForgotPass() {
        this.email = this.forgetpassForm.get('email').value.replace(/\s/g, "");
        sessionStorage.setItem("email", this.email);

        let data = {
            'email': this.email
        }
        this.spinner.show();
        this.authService.resetPassword(data).then((res: any) => {
            if (res.status == "SUCCESS") {
                this.spinner.hide();
                this.success();
            } else {
                this.spinner.hide();
                this.error("Error in password reset. Try again.");
            }
        });
    }

    submitForm() {
        this.router.navigateByUrl('/reset-password');
    }
}

