import { Component, ViewEncapsulation } from '@angular/core'
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { trigger, transition, animate, style, state } from '@angular/animations';
import { Router } from '@angular/router';
import { PasswordStrengthValidator } from '../password-strength.validators';
import { AuthenticationService } from '../../services/authentication.service';
import { NzModalService } from 'ng-zorro-antd/modal';
import { SocialAuthService } from "angularx-social-login";
import { GoogleLoginProvider } from "angularx-social-login";
import { NgxSpinnerService } from 'ngx-spinner';
@Component({
    templateUrl: './sign-up.component.html',
    animations: [trigger("fade", [state("void", style({ opacity: 0 })), transition("void <=> *", [animate("0.5s ease-in-out")])])],
    encapsulation: ViewEncapsulation.None
})
export class SignUpComponent {

    hide = true;

    tooltipVisible = true;

    signUpFormSecondStep: FormGroup;

    signUpFormThirdStep: FormGroup;

    // socialMediaFormStep: FormGroup;

    firstName: string = '';

    firstNextStepActive: boolean = true;

    selectedRole: boolean = false;

    secondNextStepActive: boolean = false;

    thirdNextStepActive: boolean = false;

    SocialMediaStepActive: boolean = false;

    showUsername: boolean = false;

    switchValue: boolean = false;

    isIn: boolean = true;

    radioValue1: string = 'Freelancer';

    selectedFirstRole: string = 'Employer';

    selectedSecondRole: string = 'Freelancer';

    chooseRole = "";
    choosedRoleType = "";

    gridStyle = {
        width: '100%',
        textAlign: 'center'
    };

    availableUserNames = [
        {
            username: "user@100"
        },
        {
            username: "user@200"
        },
        {
            username: "user@300"
        },
        {
            username: "user@400"
        },
        {
            username: "user@500"
        }
    ];

    freeoptions = [
        { label: 'Freelancer', value: 'Freelancer' },
        { label: 'Agency', value: 'Agency' }
    ];

    radioValue2: string = 'Employer';

    empOptions = [
        { label: 'Employer', value: 'Employer' },
        { label: 'Enterprise', value: 'Enterprise' }
    ]

    roleType: string;

    userRole: string;

    constructor(private fb: FormBuilder, private router: Router,
        private authService: AuthenticationService,
        private modalService: NzModalService,
        private authloginsocialService: SocialAuthService,
        private spinner: NgxSpinnerService) { }

    ngOnInit(): void {
        this.selectedAccountType();
        this.signUpFormSecondStep = this.fb.group({
            firstName: ['', Validators.compose([Validators.required, Validators.pattern('^[a-zA-Z \-\']+')])],
            lastName: ['', Validators.compose([Validators.required, Validators.pattern('^[a-zA-Z \-\']+')])],
            email: ['', Validators.compose([Validators.email, Validators.required, Validators.pattern(/^(([^<>()[\]\\.,;:\s@\"]+(\.[^<>()[\]\\.,;:\s@\"]+)*)|(\".+\"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/)])]
        });
        this.signUpFormThirdStep = this.fb.group({
            userName: [null, [Validators.required]],
            password: [null, Validators.compose([
                Validators.required, Validators.minLength(8), PasswordStrengthValidator])],
            agree: [null, [Validators.required]],
        });
        // this.socialMediaFormStep = this.fb.group({
        //     userName: [null, [Validators.required]],
        //     agree: [null, [Validators.required]],
        // });
    }

    async submitSecondForm() {
        let email: string = this.signUpFormSecondStep.get('email').value.replace(/\s/g, "");;
        let newemail = email.replace('/@/', '%40');
        let res = await this.checkIfEmailExist(newemail);
        if (res) {
            // this.error("Email already exists");
            this.errorMsg();
        }
        else {
            for (const i in this.signUpFormSecondStep.controls) {
                this.signUpFormSecondStep.controls[i].markAsDirty();
                this.signUpFormSecondStep.controls[i].updateValueAndValidity();
            }
            if (!this.signUpFormSecondStep.invalid) {
                this.nextStep3();
            }
        }
    }

    keyDown() {
        var e = window.event || e;
        var key = e.keyCode;
        //space pressed
        if (key == 32) { //space
            e.preventDefault();
        }
    }

    chooseType(type: any) {
        this.selectedRole = true;

        if (type == 'E') {
            this.switchValue = false;
            this.chooseRole = "Employer"
        } else {
            this.switchValue = true;
            this.chooseRole = "Freelancer"
        }
        this.selectedAccountType();
    }

    chooseTypeAgain() {
        this.selectedRole = false;
    }

    submitThirdForm(): void {
        for (const i in this.signUpFormThirdStep.controls) {
            this.signUpFormThirdStep.controls[i].markAsDirty();
            this.signUpFormThirdStep.controls[i].updateValueAndValidity();
        }

        if (!this.signUpFormThirdStep.invalid) {
            this.createNewAccount();
        }
    }

    async nextStep0() {
        this.selectedRole = false;
    }

    async nextStep1() {
        this.secondNextStepActive = false;
        this.firstNextStepActive = true;
        this.thirdNextStepActive = false;
    }

    nextStep2() {
        this.firstName = this.signUpFormSecondStep.controls['firstName'].value;

        this.secondNextStepActive = true;
        this.firstNextStepActive = false;
        this.thirdNextStepActive = false;
    }

    nextStep3() {
        this.secondNextStepActive = false;
        this.firstNextStepActive = false;
        this.thirdNextStepActive = true;
    }

    changeFreeAccountType(accType) {
        this.selectedSecondRole = accType;
        this.signUpFormSecondStep.reset();
        this.signUpFormThirdStep.reset();
        this.selectedAccountType();
    }

    changeEmpAccountType(accType: any) {
        this.selectedFirstRole = accType;
        this.signUpFormSecondStep.reset();
        this.signUpFormThirdStep.reset();
        this.selectedAccountType();
    }

    getUsernameCount(count: any) {
        if (count != null) {
            // this.showUsername = true;
        } else {
            this.showUsername = false;
        }
    }

    chooseUsername(username) {
        this.signUpFormThirdStep.get("userName").setValue(username);
    }

    selectedAccountType() {
        if (!this.switchValue) {
            this.userRole = "E";
            if ("Enterprise" == this.selectedFirstRole) {
                this.choosedRoleType = "Enterprise";
            }
            else {
                this.choosedRoleType = "Individual Employer";
            }
        }
        else {
            this.userRole = "F";
            if ("Agency" == this.selectedSecondRole) {
                this.choosedRoleType = "Freelance Agency";
            }
            else {
                this.choosedRoleType = "Individual Freelancer";
            }
        }
    }

    handleInput(el: any) {
        el.value = el.value.replace(/\D/g, '');
    }

    onPaste(event: ClipboardEvent, type: any) {
        let clipboardData = event.clipboardData;
        let pastedText = clipboardData.getData('text');
        let trueValue = pastedText.replace(/\s/g, "");
        setTimeout(() => {
            if (type == 'email') {
                this.signUpFormSecondStep.get('email').setValue("");
                this.signUpFormSecondStep.get('email').patchValue(trueValue);
            } else if (type == 'username') {
                this.signUpFormThirdStep.get('userName').reset;
                this.signUpFormThirdStep.get('userName').patchValue(trueValue)
            } else if (type == 'password') {
                this.signUpFormThirdStep.get('password').reset;
                this.signUpFormThirdStep.get('password').patchValue(trueValue)
            }
        }, 1);
    }

    async createNewAccount() {
        if (!this.switchValue) {
            this.userRole = "E";
            if ("Enterprise" == this.selectedFirstRole) {
                this.roleType = "E";
            }
            else {
                this.roleType = "I";
            }
        }
        else {
            this.userRole = "F";
            if ("Agency" == this.selectedSecondRole) {
                this.roleType = "A";
            }
            else {
                this.roleType = "I";
            }
        }

        let email = this.signUpFormSecondStep.get('email').value.replace(/\s/g, "");
        let password = this.signUpFormThirdStep.get('password').value.replace(/\s/g, "");
        let userName = this.signUpFormThirdStep.get('userName').value.replace(/\s/g, "");

        let cognitoData = {
            "firstName": this.signUpFormSecondStep.get('firstName').value,
            "lastName": this.signUpFormSecondStep.get('lastName').value,
            "email": email,
            "password": password,
            "userName": userName,
            "userRole": this.userRole
        }
        this.spinner.show();
        await this.authService.signUpUserCognito(cognitoData)
            .then((cognitoResp: any) => {
                if (cognitoResp.status == "SUCCESS") {
                    this.spinner.hide();
                    let signUpDbData = {
                        "emailId": cognitoData.email,
                        "cognitoId": cognitoResp.response.userSub,
                        "isUportUser": "N",
                        "role": cognitoData.userRole,
                        "roleType": this.roleType,
                        "firstName": cognitoData.firstName,
                        "lastName": cognitoData.lastName,
                        "userName": cognitoData.userName,
                        "isLoggedIn": 0,
                        "termsConditionsAgreed": "Y",
                        "userEmailVeriStatus": "P",
                        "isBussinessAssociate": "N",
                        "lastLoggedProfile": this.roleType,
                        "password": password
                    }
                    let dbReponse: any = this.authService.signUpUserDb(signUpDbData);
                    if (dbReponse) {
                        this.spinner.hide();
                        this.success();
                    }
                    else {
                        this.spinner.hide();
                        this.error("Please try again");
                    }
                }
                else {
                    this.spinner.hide();
                    this.error(cognitoResp.response.message + ". Try with different username");
                }
            });
    }

    success(): void {
        const modal = this.modalService.success({
            nzTitle: 'Email verification link has been sent successfully. Please check your inbox.',
            nzOnOk: () => this.goToSignIn()
        });
    }

    error(errorMsg: string): void {
        const modal = this.modalService.error({
            nzTitle: 'Something went wrong.',
            nzContent: errorMsg
        });
    }

    errorMsg(): void {
        const modal = this.modalService.error({
            nzTitle: 'This email is already in use. Want to log in ?',
            nzOnOk: () => this.goToSignIn(),
            // nzOnCancel:() => this.goToSignIn()
        });
    }

    goToSignIn() {
        this.router.navigateByUrl('');
    }

    async checkIfEmailExist(emailId: any) {
        return await this.authService.checkifEmailAlreadyExist(emailId);
    }

    submitForm() { }

    signInWithGoogle(): void {
        this.spinner.show();
        this.authloginsocialService.signIn(GoogleLoginProvider.PROVIDER_ID)
            .then((socialSignIndata) => {
                this.authService.signUpUserCognito(socialSignIndata)
                    .then((cognitoResp: any) => {
                        if (cognitoResp.status == "SUCCESS") {
                            let signUpDbData = {
                                "emailId": socialSignIndata.email,
                                "cognitoId": cognitoResp.response.userSub,
                                "isUportUser": "N",
                                "roleType": this.roleType,
                                "firstName": socialSignIndata.firstName,
                                "lastName": socialSignIndata.lastName,
                                "isLoggedIn": 0,
                                "userEmailVeriStatus": "N",
                                "isBussinessAssociate": "N",
                                "lastLoggedProfile": this.roleType
                            }
                            this.spinner.show();
                            let dbReponse: any = this.authService.signUpUserDb(signUpDbData);
                            if (dbReponse) {
                                this.spinner.hide();
                                this.success();
                            }
                            else {
                                this.spinner.hide();
                                this.error("Please try again");
                            }
                        }
                        else {
                            this.spinner.hide();
                            this.error(cognitoResp.response.message + ". Try with different username");
                        }
                    });
            }).catch((error) => {
                console.log(error);
            });
    }

    signOut(): void {
        this.authloginsocialService.signOut();
    }
}