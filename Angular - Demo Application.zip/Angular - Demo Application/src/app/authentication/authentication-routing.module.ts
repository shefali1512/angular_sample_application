import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { LoginComponent } from './login/login.component';
import { SignUpComponent } from './sign-up/sign-up.component';
import { ForgetPasswordComponent } from './forget-password/forget-password.component';
import { ResetPasswordComponent } from './reset-password/reset-password.component';
import { SigninCallbackComponent } from './signin-callback/signin-callback.component';

const routes: Routes = [
    {
        path: 'sign-in',
        component: LoginComponent,
        data: {
            title: 'Sign In'
        }
    },
    {
        path: 'sign-up',
        component: SignUpComponent,
        data: {
            title: 'Sign Up'
        }
    },
    {
        path: 'forget-password', 
        component: ForgetPasswordComponent,
    },
    {
        path: 'reset-password', 
        component: ResetPasswordComponent,
    },
    {
        path:'google/signin/callback',
        component: SigninCallbackComponent
    }
];
@NgModule({
    imports: [RouterModule.forChild(routes)],
    exports: [RouterModule],
})
export class AuthenticationRoutingModule { }
