import { Component, ViewEncapsulation } from '@angular/core'
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { NzModalService } from 'ng-zorro-antd/modal';
import { AuthenticationService } from 'src/app/services/authentication.service';
import { SocialAuthService } from "angularx-social-login";
import { GoogleLoginProvider } from "angularx-social-login";
import { environment } from 'src/environments/environment';
import * as SockJS from 'sockjs-client';
import * as Stomp from 'stompjs';
import { SharedService } from 'src/app/services/shared.service';
import { NgxSpinnerService } from 'ngx-spinner';

@Component({
    templateUrl: './login.component.html',
    encapsulation: ViewEncapsulation.None,
})
export class LoginComponent {

    hide = true;

    loginForm: FormGroup;

    userId: string;

    private loggedIn: boolean;

    SocialMediaStepActive: boolean = false;

    socialInfo: any = {};

    Google: any = {};

    GoogleDataDetail: any = [];

    //notification
    stompClient: any;

    listenerObserver: any;

    MINUTES_UNITL_AUTO_LOGOUT = 10 // in mins

    CHECK_INTERVAL = 15000 // in ms

    STORE_KEY = 'lastAction';

    public getLastAction() {
        return parseInt(localStorage.getItem(this.STORE_KEY));
    }

    public setLastAction(lastAction: number) {
        localStorage.setItem(this.STORE_KEY, lastAction.toString());
    }

    submitForm(): void {
        for (const i in this.loginForm.controls) {
            this.loginForm.controls[i].markAsDirty();
            this.loginForm.controls[i].updateValueAndValidity();
        }
    }

    constructor(
        private fb: FormBuilder,
        private router: Router,
        private _authenticationService: AuthenticationService,
        private _modalService: NzModalService,
        private authService: SocialAuthService,
        private sharedService: SharedService,
        private spinner: NgxSpinnerService) {
        this.check();
        this.initListener();
        this.initInterval();
        localStorage.setItem(this.STORE_KEY, Date.now().toString());
    }

    ngOnInit(): void {
        this.loginForm = this.fb.group({
            emailAdderess: [null, [Validators.required]],
            password: [null, [Validators.required]]
        });
    }
    keyDown() {
        var e = window.event || e;
        var key = e.keyCode;
        //space pressed
        if (key == 32) { //space
            e.preventDefault();
        }
    }

    onPaste(event: ClipboardEvent, type: any) {

        let clipboardData = event.clipboardData;
        let pastedText = clipboardData.getData('text');
        let trueValue = pastedText.replace(/\s/g, "");

        setTimeout(() => {
            if (type == 'email') {
                this.loginForm.get('emailAdderess').reset;
                this.loginForm.get('emailAdderess').patchValue(trueValue);
            } else if (type == 'password') {
                this.loginForm.get('password').reset;
                this.loginForm.get('password').setValue(trueValue)
            }
        }, 1);
    }

    signIn() {

        let email = this.loginForm?.get('emailAdderess').value.replace(/\s/g, "");
        let password = this.loginForm?.get('password').value.replace(/\s/g, "");
        let data = {
            'email': email,
            'password': password
        }

        this.spinner.show();
        this._authenticationService.userLoginCognito(data)
            .subscribe(async (loginResp: any) => {
                this._authenticationService.setToken(loginResp?.response?.jwtToken);

                if (loginResp?.status === 'SUCCESS') {
                    let signinId = loginResp.response.payload.email;
                    let data = {
                        'username': email,
                        'password': password
                    }
                    await this._authenticationService.getJWTToken(data).then((jwtResponse: any) => {
                        if (jwtResponse.success == 1) {
                            sessionStorage.setItem("jwtToken", jwtResponse.data.token);
                            this.loginUserFromDB(signinId);
                        } else {
                            this.error(jwtResponse.error);
                        }
                    });

                }
                else {
                    this.spinner.hide();
                    if ("NotAuthorizedException" === loginResp?.response?.code)
                        this.error(loginResp?.response?.message);
                    if ("UserNotConfirmedException" === loginResp?.response?.code)
                        this.error("Email not verified.")
                }
            });
    }

    async loginUserFromDB(signinId) {
        let ifprofExist: boolean;
        let role: string;
        let roleType: string;
        await this._authenticationService.userLogInDb(signinId)
            .then((respData: any) => {
                this.connectToWebSock();
                this.spinner.hide();
                if (respData?.userId) {
                    if (respData.freelancerProfile || respData.employerProfile) {
                        ifprofExist = true;
                    }
                    this.userId = respData.userId;
                    role = respData.role;
                    roleType = respData.roleType;

                    sessionStorage.setItem('roleType', roleType);
                    sessionStorage.setItem('role', respData.role);

                    sessionStorage.setItem('firstName', respData.firstName);
                    sessionStorage.setItem('userDetails', JSON.stringify(respData));

                    if (ifprofExist) {
                        sessionStorage.setItem("showWelcome", "true");
                        if ("E" == role) {
                            this.userId = respData.userId;
                            role = respData.role;
                            roleType = respData.roleType;
                            this.router.navigate(['employer-dashboard']);

                            sessionStorage.setItem('roleType', roleType);
                            sessionStorage.setItem('role', respData.role);

                            sessionStorage.setItem('firstName', respData.firstName);
                            sessionStorage.setItem('userDetails', JSON.stringify(respData));
                        }
                        else if ("F" == role) {
                            this.userId = respData.userId;
                            role = respData.role;
                            roleType = respData.roleType;
                            this.router.navigate(['freelancer-dashboard']);
                            sessionStorage.setItem('roleType', roleType);
                            sessionStorage.setItem('role', respData.role);

                            sessionStorage.setItem('firstName', respData.firstName);
                            sessionStorage.setItem('userDetails', JSON.stringify(respData));
                        }
                    }
                    else {
                        this.sharedService.onProfileScreen = true;
                        this.router.navigate(['landing/welcome']);
                        this.updateEmailVerifiedStatus();
                    }
                }
                else {
                    if (respData?.status == 404)
                        this.error("User not registered");
                    else
                        this.error("Server error. Please try again later")
                }
            })
    }

    error(errorMsg: string): void {
        const modal = this._modalService.error({
            nzTitle: 'Something went wrong.',
            nzContent: errorMsg
        });
    }

    connectToWebSock() {
        let url = `${environment.SPRING_SERVER_URL}websocket`;
        const socket = new SockJS(url);
        this.stompClient = Stomp.over(socket);

        this.stompClient.connect({}, () => {
            this.sharedService.stomplClient = this.stompClient;
        });
    }

    signInWithGoogle(): void {
        this.authService.signIn(GoogleLoginProvider.PROVIDER_ID)
            .then((data) => {
            }).catch((error) => {
            });
    }

    signOut(): void {
        this.authService.signOut();
    }

    updateEmailVerifiedStatus() {
        this._authenticationService.updateEmailStatus(this.userId).then((response: any) => {
            if (response) {
            }
        });
    }

    initListener() {
        document.body.addEventListener('click', () => this.reset());
        document.body.addEventListener('keydown', () => this.reset());
        document.body.addEventListener('keyup', () => this.reset());
        document.body.addEventListener('keypress', () => this.reset());
        document.body.addEventListener('scroll', () => this.reset());
    }

    initInterval() {
        setInterval(() => {
            this.check();
        }, this.CHECK_INTERVAL);

    }

    reset() {
        this.setLastAction(Date.now());
    }

    check() {
        const now = Date.now();
        const timeleft = this.getLastAction() + this.MINUTES_UNITL_AUTO_LOGOUT * 60 * 1000;
        const diff = timeleft - now;

        const isTimeout = diff < 0;

        if (isTimeout) {
            localStorage.clear();
            this.router.navigate(['./sign-in']);
        }
    }
}