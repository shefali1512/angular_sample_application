import { AbstractControl, ValidationErrors } from "@angular/forms";

export const PasswordStrengthValidator = function (control: AbstractControl): ValidationErrors | null {

    let value: string = control.value || '';

    if (!value) {
        return null;
    }

    let upperCaseCharacters = /[A-Z]+/g;
    let lowerCaseCharacters = /[a-z]+/g;
    let numberCharacters = /[0-9]+/g;
    let specialCharacters = /[!@#$%^&*()_+\-=\[\]{};':"\\|,.<>\/?]+/;

    if (upperCaseCharacters?.test(value) === false || lowerCaseCharacters?.test(value) === false || numberCharacters?.test(value) === false || specialCharacters?.test(value) === false) {
        return {
            passwordStrength: 'Password should be at least 8 characters long, along with both lower and upper case characters, at least one number and at least one special symbol.'
        }
    }
}