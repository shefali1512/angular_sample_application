import { NgModule } from '@angular/core';
import { RouterModule, Routes, PreloadAllModules } from '@angular/router';
import { Error1Component } from './authentication/error-1/error-1.component';

const appRoutes: Routes = [
    {
        path: '', 
        redirectTo: 'sign-in',
        pathMatch: 'full'
    },
    {
        path: '',
        loadChildren: () => import('./authentication/authentication.module').then(m => m.AuthenticationModule)
    },
    {
        path: 'employer-dashboard',
        loadChildren: () => import('./pages/employer-dashboard/dashboard.module').then(m => m.EmployerDashboardModule)
    },
    {
        path: 'freelancer-dashboard',
        loadChildren: () => import('./pages/freelancer-dashboard/dashboard.module').then(m => m.FreelancerDashboardModule)
    },
    {
        path: 'landing',
        loadChildren: () => import('./pages/landing/landing.module').then(m => m.LandingModule)
    },
    {
        path: 'setting',
            loadChildren: () => import('./pages/settings/settings.module').then(m => m.SettingsModule)
     },
     {
        path: 'user-timeline',
        loadChildren: () => import('./pages/user-timeline/user-timeline.module').then(m => m.UserTimelineModule)
    },
    {
        path: 'post-project',
        loadChildren: () => import('./pages/post-project/post-project.module').then(m => m.PostProjectModule)
    },
    {
        path: 'employer-tabs',
        loadChildren: () => import('./pages/employer-tabs/employer-tabs.module').then(m => m.EmployerTabsModule)
    },
    {
        path: 'recommend-freelancer',
        loadChildren: () => import('./pages/recommend-freelancers/recommend-freelancers.module').then(m => m.RecommendFreelancersModule)
    },
    {
        path: 'free-profile-short-view',
        loadChildren: () => import('./pages/free-profile-short-view/free-profile-sview.module').then(m => m.FreeProfileSviewModule)
    },
    {
        path: 'emp-project-short-view',
        loadChildren: () => import('./pages/emp-project-short-view/emp-project-short-view.module').then(m => m.EmpProjectShortViewModule)
    },
    {
        path: 'free-workpackage-tabs',
        loadChildren: () => import('./pages/free-workpackage-tab/free-workpackage-tabs.module').then(m => m.FreeWorkpackageTabsModule)
    },
    {
        path: 'employer-offer',
        loadChildren: () => import('./pages/employer-offer/employer.module').then(m => m.EmployerOfferModule)
    },
    {
        path: 'create-contract',
        loadChildren: () => import('./pages/create-contract-employer/create-contract.module').then(m => m.CreateContractModule)
    },
    {
        path: 'freelancer-offer',
        loadChildren: () => import('./pages/freelancer-offer/freelancer-offer.module').then(m => m.FreelancerOfferModule)
    },
    {
        path: 'view-contract',
        loadChildren: () => import('./pages/view-contract-employer/view-contract.module').then(m => m.ViewContractModule)
    },
    {
        path: 'notifications',
        loadChildren: () => import('./pages/notifications/notifications.module').then(m => m.NotificationsModule)
    },
    {
        path: 'freelancer-contract-details',
        loadChildren: () => import('./pages/freelancer-contract/freelancer-contract-details.module').then(m => m.FreelancerContractDetailsModule)
    },
    {
        path: 'employer-contract-details',
        loadChildren: () => import('./pages/employer-contract/employer-contract.module').then(m => m.EmployerContractModule)
    },
    {
        path: 'employer-globalsearch',
        loadChildren: () => import('./pages/global-search/employer-globalsearch/employer-globalsearch.module').then(m => m.EmployerGlobalsearchModule)
    },
    {
        path: 'freelancer-globalsearch',
        loadChildren: () => import('./pages/global-search/freelancer-globalsearch/freelancer-globalsearch.module').then(m => m.FreelancerGlobalsearchModule)
    },
  
    {   path: '404', 
        component: Error1Component,
    },
    {
        path: '**', 
        redirectTo: '/404',
    }
];

@NgModule({
    imports: [
        RouterModule.forRoot(appRoutes, {
            preloadingStrategy: PreloadAllModules,
            anchorScrolling: 'enabled',
            scrollPositionRestoration: 'enabled'
        })
    ],
    exports: [
        RouterModule
    ]
})

export class AppRoutingModule { }