export interface IBreadcrumb {
    label: string;
    url: string;
}
