import { Component, Input, OnInit } from '@angular/core';
import { ThemeConstantService } from '../../services/theme-constant.service';
import { MasterService } from '../../../services/master.service';
import { Router, NavigationEnd } from '@angular/router';
import { EmployerDashboardService } from 'src/app/services/employer-dashboard.service';
import { SharedService } from 'src/app/services/shared.service';
import { SocialAuthService } from 'angularx-social-login';
import { AuthenticationService } from 'src/app/services/authentication.service';
import { ProfileService } from 'src/app/services/profile.service';
import { lastDayOfDecade } from 'date-fns';
@Component({
    selector: 'app-header',
    templateUrl: './header.component.html'
})

export class HeaderComponent implements OnInit {

    employerDetails: any = [];

    freelancerDetails: any = [];

    roleType: any;

    indiviualFree: boolean = false;

    Freeagency: boolean = false;

    indiviualEmp: boolean = false;

    Entprise: boolean = false;

    commonprofile: boolean = false;

    role: any;

    freePhoto: any;

    empPhoto: any;

    showemp: boolean = false;

    showfree: boolean = false;

    photo: any;

    image: any;

    ffirstName: any;

    flastName: any;

    efirstName: any;

    elastName: any;

    freeData: any;

    empData: any;

    @Input()
    isEmployerDashboard: Object = null;

    @Input()
    accountSettings;

    @Input()
    isFreelancerDashboard: Object = null;

    @Input()
    freeProfiledata: Object = null

    @Input()
    uploadfreeProfiledata: Object = null;

    @Input()
    empuploadProfiledata: Object = null;

    @Input()
    employerProfiledata: Object = null

    searchVisible: boolean = false;

    isSearchVisible: boolean = true;

    quickViewVisible: boolean = false;

    isFolded: boolean = false;

    isExpand: boolean = false;

    isEmployer: boolean = false;


    notificationList = [
        {
            title: 'You received a new message',
            time: '8 min',
            icon: 'mail',
            color: 'ant-avatar-' + 'blue'
        },
        {
            title: 'New user registered',
            time: '7 hours',
            icon: 'user-add',
            color: 'ant-avatar-' + 'cyan'
        },
        {
            title: 'System Alert',
            time: '8 hours',
            icon: 'warning',
            color: 'ant-avatar-' + 'red'
        },
        {
            title: 'You have a new update',
            time: '2 days',
            icon: 'sync',
            color: 'ant-avatar-' + 'gold'
        }
    ];
    localData: any;

    constructor(
        private _themeService: ThemeConstantService,
        private _masterService: MasterService,
        public router: Router,
        private sharedService: SharedService,
        private authService: AuthenticationService,
        private _profileService: ProfileService,
        private _employerDetails: EmployerDashboardService,
    ) {
        this.router.events.subscribe((event) => {
            if (event instanceof NavigationEnd) {
                if (event?.url === '/landing/welcome') {
                    this.isSearchVisible = false;
                } else {
                    this.isSearchVisible = true;
                }
            }
        });
    }

    ngOnChanges() {
        // console.log("skc");
        if (this.employerProfiledata) {
            this.showemp = true;
            this.showfree = false;
            // this.employerProfiledata;
            // console.log("this.employerProfiledata",this.employerProfiledata);
            if (this.empuploadProfiledata) {
                this.empPhoto = this.empuploadProfiledata;
                // // console.log("this.empuploadProfiledata;", this.empuploadProfiledata);
            } else {
                this.employerDetails.push(this.employerProfiledata);
                this.employerDetails.forEach(empprofilePhoto => {
                    this.empPhoto = atob(empprofilePhoto.photo);
                });
            }
        }
        if (this.freeProfiledata) {
            this.showfree = true;
            this.showemp = false;
            // console.log("this.freeProfiledata",this.freeProfiledata);
            if (this.uploadfreeProfiledata) {
                this.freePhoto = this.uploadfreeProfiledata;
                // // console.log("this.freeuploadfreeProfiledata;", this.uploadfreeProfiledata);
            } else {
                this.freelancerDetails.push(this.freeProfiledata);
                this.freelancerDetails.forEach(freeprofilePhoto => {
                    this.freePhoto = atob(freeprofilePhoto.photo);
                });
            }
        }

    }

    ngOnInit(): void {
        this.localData = JSON.parse(sessionStorage.getItem("userDetails"));
        if (this.localData.role === "E") {
            this.showemp = true;
            this.showfree = false;
        }
        if (this.localData.role === "F") {
            this.showfree = true;
            this.showemp = false;
        }
        this.getUserDetails(this.localData.userId);
        this.role = this.localData?.role;
        this.roleType = this.localData?.roleType
        if (this.roleType === 'E') {
            this.Entprise = true;
        }
        if (this.roleType === 'I' && this.role === 'F') {
            this.indiviualFree = true;
        }
        if (this.roleType === 'A') {
            this.Freeagency = true;

        } if (this.roleType === 'I' && this.role === 'E') {
            this.isEmployer = true;
        }

        if (this.roleType === 'A' && this.role === 'F') {
            this.commonprofile = true;
        }
        if (this.roleType === 'I' && this.role === 'E') {
            this.commonprofile = true;
        }
    }

    getUserDetails(userId: any) {

        // console.log("userId",userId);
        if (this.localData.role === "F") {
            this._profileService.getFreelancerProfileDetails(userId)
                .subscribe(
                    (response) => {
                        this.freeData = response;
                        this.freeProfiledata= response;
                        // console.log("this.freeData", this.freeData);
                        // this.freelancerDetails.push(this.freeData);
                        if (this.freeData.photo) {
                            this.freePhoto = atob(this.freeData.photo);
                        }
                    },
                    (error) => {
                        // // console.log(error);
                    },
                    () => { }
                );
        }
        if (this.localData?.role === "E") {
            this._employerDetails.getEmployerProfileData(userId)
                .subscribe(
                    (responseEmployer: any) => {
                        // console.log('getProfileDetails:', getProfileDetails);
                        this.empData = responseEmployer;
                        this.employerProfiledata = responseEmployer;
                        // console.log("this.employerProfiledata", this.employerProfiledata);
                        if (this.empData.photo) {
                            // console.log("this.empData.photo" , this.empData.photo);

                            this.empPhoto = atob(this.empData.photo);
                        }
                    },
                    (error) => {
                        // // console.log(error);
                    },
                    () => { }
                );
        }
        // else{
        //     this._employerDetails.getEmployerProfileData(userId)
        //     .subscribe(
        //         (getProfileDetails) => {
        //             // console.log('getProfileDetails:', getProfileDetails);
        //             this.empData = getProfileDetails;
        //             //this.employerProfiledata = this.empProfileData;
        //             // console.log("empData",this.empData)
        //             this.employerDetails.push(this.empData);
        //             this.employerDetails.forEach(empprofilePhoto => {
        //                 this.empPhoto = atob(empprofilePhoto.photo);
        //             });
        //         },
        //         (error) => {
        //             // // console.log(error);
        //         },
        //         () => { }
        //     );
        // }


    }
    toggleFold() {
        this.isFolded = !this.isFolded;
        this._themeService.toggleFold(this.isFolded);
    }

    gotoDashboard() {
        // console.log("this.isEmployer" , this.isEmployer);
        // console.log("this.sharedService.onProfileScreen" , this.sharedService.onProfileScreen);

        if (this.isEmployer && !this.sharedService.onProfileScreen) {
            // // console.log("this.sharedService.onProfileScreen",this.sharedService.onProfileScreen)
            this.router.navigateByUrl('/employer-dashboard');
        }
        else if (!this.isEmployer && !this.sharedService.onProfileScreen) {
            this.router.navigateByUrl('/freelancer-dashboard');
        }
    }

    toggleExpand() {
        this.isFolded = false;
        this.isExpand = !this.isExpand;
        this._themeService.toggleExpand(this.isExpand);
        this._themeService.toggleFold(this.isFolded);
    }

    searchToggle(): void {
        this.searchVisible = !this.searchVisible;
    }

    quickViewToggle(): void {
        this.quickViewVisible = !this.quickViewVisible;
    }

    logout() {
        localStorage.clear();
        sessionStorage.clear();
        this.authService.signOut(this.localData.userId).then((response) => {
            if (response) {
            }
        });
        this.router.navigate(['sign-in']);
    }

    openUserChatList() {
        this._masterService.setUserChatListMode(true);
    }

}
