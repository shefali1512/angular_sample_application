import { CUSTOM_ELEMENTS_SCHEMA, NgModule } from '@angular/core';
import { CommonModule } from "@angular/common";
import { ReactiveFormsModule } from '@angular/forms';
import { SharedModule } from '../../shared/shared.module';
import { AntDesignModule } from "../../ant-design/ant-design.module";
import { EndContractSuccesComponent } from './end-contract-succes/end-contract-succes.component';
import { EndContractComponent } from './end-contract/end-contract.component';
import { ErrorEndContractComponent } from './error-end-contract/error-end-contract.component';
import { EndrContractRoutingModule } from './end-contract-routing.module';
import { EndContractFreeComponent } from './end-contract-free/end-contract-free.component';

@NgModule({
    imports: [
        CommonModule,
        SharedModule,
        ReactiveFormsModule,
        AntDesignModule,
        EndrContractRoutingModule
        
    ],
    declarations: [
        ErrorEndContractComponent,
        EndContractComponent,
        EndContractSuccesComponent,
        EndContractFreeComponent
    ],
    exports:[
        ErrorEndContractComponent,
        EndContractComponent,
        EndContractSuccesComponent,
        EndContractFreeComponent
    ],
    schemas: [CUSTOM_ELEMENTS_SCHEMA]
})

export class EndContractModule {}