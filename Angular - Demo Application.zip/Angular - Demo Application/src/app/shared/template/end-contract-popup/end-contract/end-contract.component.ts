import { EventEmitter, Component, Input, OnInit, Output } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { MilestoneService } from 'src/app/services/milestone.service';
import { DatePipe } from '@angular/common';
import { SharedService } from 'src/app/services/shared.service';
import { RatingreviewService } from 'src/app/services/rating-review.service';

@Component({
  selector: 'app-end-contract',
  templateUrl: './end-contract.component.html',
  styleUrls: []
})
export class EndContractComponent implements OnInit {
  
 @Output()
 feedbackRateReviewEmpInfo: EventEmitter<boolean> = new EventEmitter;

  ratingType: any = [];

  FeedbackRatingForm:FormGroup;

  endContractDate: Date = new Date();

  publicComment: any;

  workPackageContractId:"2";

  userRole: any = "employer";

  roleType: any;

  masterRatingType: any = [];

  aWorkPackageId: any;

  bWorkPackageContractId: any;

  commentLength: boolean;

  characters: number = 500;

  maxCharacters: number = 500;

  stompClient: any;

  value = 0;

  @Input()
  actionType: string = null;


  @Output()
  onCloseAddModal: EventEmitter<boolean> = new EventEmitter(false);

  today: Date = new Date();

  maxDate: Date = new Date(new Date().getFullYear() + 1, 11, 31);

  totalMilestoneAmountAdd: any;

  currentRatingDate: any;

  commRate:any;

  qualityOfWorkRate:any;

  onTImeDeliveryRate:any;

  skillRate:any;


  feedbackDetails = [
    {
        id: 1,
        name: "Feedback from me",
        status: 1,
        feedbackDate: 'Aug 20 2020',
        feedbackDescription: 'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industrys standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.',
        communication: 0,
        qualityOfWork: 0,
        onTImeDelivery: 0,
        skill: 0,
    },
]


  constructor(private fb: FormBuilder, private _milestoneService: MilestoneService,
    public datePipe: DatePipe, private sharedService: SharedService, private ratingreviewService:RatingreviewService) {
    this.currentRatingDate = this.datePipe.transform(new Date(), 'yyyy-MM-dd');
  }

  ngOnChanges() {
  }

  ngOnInit(): void {
    this.endContractData();
  }

  endContractData(){
    this.FeedbackRatingForm = this.fb.group({
      comment: [null, [Validators.required]],
  });
  }


  submitForm(): void {
  this.FeedbackRatingForm.value.comment;
  
  this.actionType = null;
  }

  onCancelAddProposal() {
    this.onCloseAddModal.emit(true);
  }

  NzRateClickedComm() {
    this.commRate = this.feedbackDetails[0].communication;
  }
  
  NzRateClickedTechskills() {
    this.skillRate = this.feedbackDetails[0].skill;
  }

  NzRateClickedQauwk() {
    this.qualityOfWorkRate = this.feedbackDetails[0].qualityOfWork;
  }

  NzRateClickedontimedelivery() {
    this.onTImeDeliveryRate = this.feedbackDetails[0]. onTImeDelivery;
  }

  allEmpFeedRatingReview(){
    
  }


}