import { EventEmitter, Component, Input, OnInit, Output } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { MilestoneService } from 'src/app/services/milestone.service';
import { DatePipe } from '@angular/common';
import { SharedService } from 'src/app/services/shared.service';
import { RatingreviewService } from 'src/app/services/rating-review.service';

@Component({
  selector: 'app-end-contract-free',
  templateUrl: './end-contract-free.component.html',
  styleUrls: []
})
export class EndContractFreeComponent implements OnInit {

  FeedbackRatingForm:FormGroup;

  @Output()
  freeFeedbkRatingInfo: EventEmitter<boolean> = new EventEmitter;

  ratingType: any = [];

  endContractDate: Date = new Date();

  publicComment: any;

  workPackageContractId:"2";

  userRole: any = "employer";

  roleType: any;

  masterRatingType: any = [];

  aWorkPackageId: any;

  bWorkPackageContractId: any;

  commentLength: boolean;

  characters: number = 500;

  maxCharacters: number = 500;

  stompClient: any;

  @Input()
  actionType: string = null;

  @Output()
  onCloseAddModal: EventEmitter<boolean> = new EventEmitter(false);

  @Input()
  dataByInput: string = null;

  GSTInfocommon: any = {};

  feedbackForm!: FormGroup;

  checkNatureoftaransaction: any;

  responseMileData: any;

  freelancerOfferMilestoneType: any

  totalMileAmt: any;

  addNewMileList: any = [];

  workPackageAmt: any;

  amtExceed: boolean = false;

  interstateigst: boolean;

  addOffermilestone: any;

  addProposalmilestone: any;

  gstvalue: any;

  enterAmount: any;

  intrastatesgstcgst: boolean;

  igstCalculatedvalue: any;

  cgstsgstCalculatedvalue: any;

  cgstCalvalue: any;

  sgstCalvalue: any;

  today: Date = new Date();

  maxDate: Date = new Date(new Date().getFullYear() + 1, 11, 31);

  totalMilestoneAmountAdd: any;

  currentProposalDate: any;

  commRate:any;

  cliOfwkRate:any;

  professionalismRate:any;

  paymentpromptnessRate:any;

  feedbackDetails = [
    {
        id: 1,
        name: "Feedback from me",
        status: 1,
        feedbackDate: 'Aug 20 2020',
        feedbackDescription: 'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industrys standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.',
        communication: 0,
        cliOfWork: 0,
        professionalism: 0,
        paymentpromptness: 0,
    },
    // {
    //     id: 2,
    //     name: "Feedback to me",
    //     status: 1,
    //     feedbackDate: 'Aug 20 2020',
    //     feedbackDescription: 'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industrys standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.',
    //     communication: 4,
    //     qualityOfWork: 3,
    //     onTImeDelivery: 3,
    //     skill: 3,
    // }
]


  constructor(private fb: FormBuilder, private _milestoneService: MilestoneService,
    public datePipe: DatePipe, private sharedService: SharedService, private ratingReview:RatingreviewService) {
    this.currentProposalDate = this.datePipe.transform(new Date(), 'yyyy-MM-dd');
  }

  ngOnChanges() {

  }

  ngOnInit(): void {
    this.feedbackForm = this.fb.group({
      comment: ['', [Validators.required]],
    });
    this.workPackageAmt = this.feedbackForm.value.amount;
    this.totalMileAmt = this.feedbackForm.value.amount;
  }



  submitForm(): void {
   
  }

  onCancelAddProposal() {
    this.onCloseAddModal.emit(true);
  }
  
  NzRateClickedComm(event:any) {
    // console.log("communication",this.feedbackDetails[0].communication);
    this.commRate = this.feedbackDetails[0].communication;
    // console.log("commRate",this.commRate);
  }
  
  NzRateClickedCliwk(event) {
    // console.log("cliOfWork",this.feedbackDetails[0].cliOfWork);
    this.cliOfwkRate = this.feedbackDetails[0].cliOfWork; 
  }

  NzRateClickedprof(event) {
    // console.log("professionalism",this.feedbackDetails[0].professionalism);
    this.professionalismRate = this.feedbackDetails[0].professionalism;
  }

  NzRateClickedpaypro(event) {
    // console.log("paymentpromptness",this.feedbackDetails[0].paymentpromptness);
    this.paymentpromptnessRate = this.feedbackDetails[0].paymentpromptness;
  }

  endContractData(){
    this.FeedbackRatingForm = this.fb.group({
      comment: [null, [Validators.required]],
  });
  }

}