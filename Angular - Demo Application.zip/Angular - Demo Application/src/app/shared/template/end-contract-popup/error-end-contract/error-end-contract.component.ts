import { EventEmitter, Component, Input, OnInit, Output } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { MilestoneService } from 'src/app/services/milestone.service';
import { DatePipe } from '@angular/common';
import { SharedService } from 'src/app/services/shared.service';

@Component({
  selector: 'app-error-end-contract',
  templateUrl: './error-end-contract.component.html',
  styleUrls: []
})
export class ErrorEndContractComponent implements OnInit {

  @Input()
  actionType: string = null;

  @Input()
  natureoftransactionData: Object = null;

  @Input()
  gstPercentageData: Object = null;

  @Output()
  onCloseAddModal: EventEmitter<boolean> = new EventEmitter(false);

  @Output()
  offerMilestoneInfo: EventEmitter<boolean> = new EventEmitter;

  @Output()
  sendproposlMilestoneInfo: EventEmitter<boolean> = new EventEmitter;

  @Input()
  dataByInput: string = null;

  GSTInfocommon: any = {};

  addNewMilestoneForm!: FormGroup;

  checkNatureoftaransaction: any;

  responseMileData: any;

  freelancerOfferMilestoneType: any

  totalMileAmt: any;

  addNewMileList: any = [];

  workPackageAmt: any;

  amtExceed: boolean = false;

  interstateigst: boolean;

  addOffermilestone: any;

  addProposalmilestone: any;

  gstvalue: any;

  enterAmount: any;

  intrastatesgstcgst: boolean;

  igstCalculatedvalue: any;

  cgstsgstCalculatedvalue: any;

  cgstCalvalue: any;

  sgstCalvalue: any;

  today: Date = new Date();

  maxDate: Date = new Date(new Date().getFullYear() + 1, 11, 31);

  totalMilestoneAmountAdd: any;

  currentProposalDate: any;

  constructor(private fb: FormBuilder, private _milestoneService: MilestoneService,
    public datePipe: DatePipe, private sharedService: SharedService) {
    this.currentProposalDate = this.datePipe.transform(new Date(), 'yyyy-MM-dd');
  }

  ngOnChanges() {
    // console.log("actionType", this.actionType);
    this.dataByInput;
    if (this.natureoftransactionData) {
      if (this.natureoftransactionData === "In") {
        this.interstateigst
      } else {
        this.intrastatesgstcgst
      }
      this.checkNatureoftaransaction = this.natureoftransactionData;
      this.getTransactionsData();
    }

    if (this.gstPercentageData) {
      this.gstvalue = this.gstPercentageData
      this.getGSTData();
    }
  }

  ngOnInit(): void {
    this.addNewMilestoneForm = this.fb.group({
      milestone: ['', [Validators.required]],
      comment: ['', [Validators.required]],
      deliveryDate: ['', [Validators.required]],
      amount: ['', [Validators.required]],
      transaction: [''],
      gst: ['', [Validators.required]],
      cgstamount: ['', [Validators.required]],
      sgstamount: ['', [Validators.required]],
      igstamount: ['', [Validators.required]],
    });
    this.workPackageAmt = this.addNewMilestoneForm.value.amount;
    this.totalMileAmt = this.addNewMilestoneForm.value.amount;
  }

  getTransactionsData() {
    this.addNewMilestoneForm.patchValue({
      transaction: this.natureoftransactionData
    });
  }

  getGSTData() {
    this.addNewMilestoneForm.patchValue({
      gst: this.gstPercentageData
    });
  }

  getIGSTData() {
    if (this.enterAmount) {
      this.igstCalculatedvalue = this.gstvalue * this.enterAmount / 100;
      this.addNewMilestoneForm.patchValue({
        igstamount: this.igstCalculatedvalue
      });
    }
  }

  getSGSTCGSTData() {
    if (this.enterAmount) {
      this.cgstsgstCalculatedvalue = this.gstvalue * this.enterAmount / 100;
      this.cgstCalvalue = this.cgstsgstCalculatedvalue / 2;
      this.sgstCalvalue = this.cgstsgstCalculatedvalue / 2;
      this.addNewMilestoneForm.patchValue({
        cgstamount: this.cgstCalvalue,
        sgstamount: this.sgstCalvalue
      });
    }
  }

  submitForm(): void {
    if (this.dataByInput === "offerMie") {
      this.totalMilestoneAmountAdd =  this.addNewMilestoneForm.value.amount + this.addNewMilestoneForm.value.igstamount;
      let datenew = this.datePipe.transform(new Date(this.addNewMilestoneForm.value.deliveryDate), 'yyyy-MM-dd');
      let addMilestoneData = {
        "offerMilestoneAmount": this.addNewMilestoneForm.value.amount,
        "offerMilestoneDate": this.currentProposalDate,
        "offerMilestoneDeliveryDate": datenew,
        "offerMilestoneDescription": this.addNewMilestoneForm.value.comment,
        "offerMilestoneName": this.addNewMilestoneForm.value.milestone,
        "sgstamount": this.addNewMilestoneForm.value.sgstamount,
        "cgstamount": this.addNewMilestoneForm.value.cgstamount,
        "igstamount": this.addNewMilestoneForm.value.igstamount,
        "totalMilestoneAmount": this.totalMilestoneAmountAdd
      }
      this.addOffermilestone = addMilestoneData
      // this.addNewMileList.push(addMilestoneData);  
      this.offerMilestoneInfo.emit(this.addOffermilestone);
      this.onCloseAddModal.emit(true);
      for (const i in this.addNewMilestoneForm?.controls) {
        this.addNewMilestoneForm?.controls[i]?.markAsDirty();
        this.addNewMilestoneForm?.controls[i]?.updateValueAndValidity();
      }
    } else {
      if (this.totalMilestoneAmountAdd) {
        this.totalMilestoneAmountAdd = this.addNewMilestoneForm.value.sgstamount + this.addNewMilestoneForm.value.cgstamount;
      } else {
        this.totalMilestoneAmountAdd = this.addNewMilestoneForm.value.amount
      }
      this.totalMilestoneAmountAdd =  this.addNewMilestoneForm.value.amount + this.addNewMilestoneForm.value.igstamount;
      let datenew = this.datePipe.transform(new Date(this.addNewMilestoneForm.value.deliveryDate), 'yyyy-MM-dd');
      let addMilestoneData = {
        "proposalMilestoneAmount": this.addNewMilestoneForm.value.amount,
        "proposalMilestoneDate": this.currentProposalDate,
        "proposalMilestoneDeliveryDate": datenew,
        "proposalMilestoneDescription": this.addNewMilestoneForm.value.comment,
        "proposalMilestoneName": this.addNewMilestoneForm.value.milestone,
        "sgstamount": this.addNewMilestoneForm.value.sgstamount,
        "cgstamount": this.addNewMilestoneForm.value.cgstamount,
        "igstamount": this.addNewMilestoneForm.value.igstamount,
        "totalMilestoneAmount": this.totalMilestoneAmountAdd
      }
      this.addProposalmilestone = addMilestoneData;
      this.sendproposlMilestoneInfo.emit(this.addProposalmilestone);
      // this.isMilestoneCreated.emit(true);
      this.onCloseAddModal.emit(true);

      for (const i in this.addNewMilestoneForm?.controls) {
        this.addNewMilestoneForm?.controls[i]?.markAsDirty();
        this.addNewMilestoneForm?.controls[i]?.updateValueAndValidity();
      }
    }
  }

  onCancelAddProposal() {
    this.onCloseAddModal.emit(true);
  }

  numberOnly(event): boolean {
    const charCode = event.which ? event.which : event.keyCode;
    if (charCode > 31 && (charCode < 48 || charCode > 57)) {
      return false;
    }
    return true;
  }

  checkAmount(event) {
    this.enterAmount = event?.target?.value;

    if (this.enterAmount) {
      if (this.checkNatureoftaransaction == "In") {
        this.getIGSTData();
      } else {
        this.getSGSTCGSTData();
      }
    }

    if ((parseInt(this.totalMileAmt) + parseInt(this.addNewMilestoneForm.value.amount)) > this.workPackageAmt) {
      this.amtExceed = true;
    } else {
      this.amtExceed = false;
    }
  }
}