import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { CommonLayoutComponent } from '../../layouts/common-layout/common-layout.component';
import { EndContractSuccesComponent } from './end-contract-succes/end-contract-succes.component';



const routes: Routes = [
    // {
    //     path: '',
    //     component: CommonLayoutComponent,
    //     children: [
    //         {
    //             path: '',
    //             component: FreelancerContractDetailsComponent
    //         }
    //     ]
    // }
    {
        path:'',
        component:EndContractSuccesComponent
        
    }
    

    

];

@NgModule({
    imports: [RouterModule.forChild(routes)],
    exports: [RouterModule],
})
export class EndrContractRoutingModule { }
