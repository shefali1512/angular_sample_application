import { Component, OnInit, ViewEncapsulation } from '@angular/core';
@Component({
  selector: 'app-spinner',
  templateUrl: './ngx-spinner.component.html',
  encapsulation: ViewEncapsulation.None
})
export class NgxSpinnerComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
   
  }
}
