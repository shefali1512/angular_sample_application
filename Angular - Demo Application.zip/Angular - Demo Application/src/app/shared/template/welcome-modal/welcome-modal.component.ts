import { Component, Input } from '@angular/core';
import { SharedService } from 'src/app/services/shared.service';

@Component({
    selector: 'app-welcome-modal',
    templateUrl: './welcome-modal.component.html',
    styleUrls: ['./welcome-modal.component.scss'],
})

export class WelcomeModalComponent {


    @Input()
    actionType: string = null;

    @Input()
    userDetailsfirstname: string = null;

    userDetails: any;
    showEmpFirstStep: boolean = true;
    showEmpSecondStep: boolean = false;
    showEmpThirdStep: boolean = false;

    showFreelancerFirstStep: boolean = true;
    showFreelancerSecondStep: boolean = false;
    showFreelancerThirdStep: boolean = false;

    constructor(
        private _sharedService: SharedService,
    ) { }

    ngOnChanges() {

    }

    ngOnInit(): void {
        this.userDetails = JSON.parse(sessionStorage.getItem('userDetails'));
    }

    closeWelcomeModal(actionType: string) {
        if (this.userDetails.role == 'E') {
            this._sharedService.showEmpWelcomeModal = false;
        }
        else if (this.userDetails.role == 'F') {
            this._sharedService.showFreeWelcomeModal = false;
        }
        this.actionType = actionType;
        sessionStorage.setItem("showWelcome", "false");
    }

    clickOnCancelCertModal() {

    }


    onNextFreelancer1() {
        this.showFreelancerFirstStep = false;
        this.showFreelancerSecondStep = true;
        this.showFreelancerThirdStep = false;
    }

    onNextFreelancer2() {
        this.showFreelancerFirstStep = false;
        this.showFreelancerSecondStep = false;
        this.showFreelancerThirdStep = true;
    }


    onNextEmployer1() {
        this.showEmpFirstStep = false;
        this.showEmpSecondStep = true;
        this.showEmpThirdStep = false;
    }

    onNextEmployer2() {
        this.showEmpFirstStep = false;
        this.showEmpSecondStep = false;
        this.showEmpThirdStep = true;
    }
    getStartedEmployer() {
        this.actionType = null;
        this._sharedService.showEmpWelcomeModal = false;
    }

    getStartedFreelancers(){
      this.actionType = null;
      this._sharedService.showFreeWelcomeModal = false;
    }
}