import { Component, Input, OnInit } from '@angular/core';
import { ThemeConstantService } from '../../services/theme-constant.service';
import { MasterService } from '../../../services/master.service';
import { Router, NavigationEnd } from '@angular/router';
import { EmployerDashboardService } from 'src/app/services/employer-dashboard.service';
import { SharedService } from 'src/app/services/shared.service';
import { SocialAuthService } from 'angularx-social-login';
import { AuthenticationService } from 'src/app/services/authentication.service';
import { ProfileService } from 'src/app/services/profile.service';
import { lastDayOfDecade } from 'date-fns';
@Component({
    selector: 'app-header-one',
    templateUrl: './header-one.component.html'
})

export class HeaderOneComponent implements OnInit {

    localData: any;

    constructor(
        private _themeService: ThemeConstantService, 
        private _masterService: MasterService, 
        public router: Router,
        private sharedService: SharedService,
        private authService : AuthenticationService,
        private _profileService : ProfileService,
        private _employerDetails : EmployerDashboardService,
        ) {
        this.router.events.subscribe((event) => {
            if (event instanceof NavigationEnd) {
                if (event?.url === '/landing/welcome') {
                    // this.isSearchVisible = false;
                } else {
                    // this.isSearchVisible = true;
                }
            }
        });
    }

    ngOnChanges(){    
   
     
    }

    ngOnInit(): void {
        this.localData = JSON.parse(sessionStorage.getItem("userDetails"));
    }
 
    

    
    logout() {
        localStorage.clear();
        sessionStorage.clear();
        this.authService.signOut(this.localData.userId).then((response)=>{
            if(response){
            }
        });
        this.router.navigate(['sign-in']);
    }

  
}
