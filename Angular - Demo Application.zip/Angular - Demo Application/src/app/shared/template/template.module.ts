import { CommonModule } from "@angular/common";
import { RouterModule } from "@angular/router";
import { SharedModule } from '../shared.module';
import { CUSTOM_ELEMENTS_SCHEMA, NgModule } from '@angular/core';
// import { NzAvatarModule } from 'ng-zorro-antd/avatar';
// import { NzBadgeModule } from 'ng-zorro-antd/badge';
// import { NzRadioModule } from 'ng-zorro-antd/radio';
// import { NzDropDownModule } from 'ng-zorro-antd/dropdown';
// import { NzListModule } from 'ng-zorro-antd/list';
// import { NzDrawerModule } from 'ng-zorro-antd/drawer';
// import { NzDividerModule } from 'ng-zorro-antd/divider';
// import { NzSwitchModule } from 'ng-zorro-antd/switch';
// import { NzInputModule } from 'ng-zorro-antd/input';
// import { NzButtonModule } from 'ng-zorro-antd/button';
import { AntDesignModule } from '../../ant-design/ant-design.module';

import { CommonHeaderComponent } from "./header-common/common-header.component";
import { SearchComponent } from "./search/search.component";
import { QuickViewComponent } from './quick-view/quick-view.component';
import { SideNavComponent } from "./side-nav/side-nav.component";
import { FooterComponent } from "./footer/footer.component";
import { WelcomeModalComponent } from './welcome-modal/welcome-modal.component';

import { SideNavDirective } from "../directives/side-nav.directive";
import { ThemeConstantService } from '../services/theme-constant.service';
import { HeaderComponent } from './header/header.component';
import { HeaderOneComponent } from './header one/header-one.component';
import { NgxSpinnerComponent } from "./loader/ngx-spinner.component";
import { OTPComponent } from "./OTP/otp.component";



const antdModule = [
    // NzAvatarModule,
    // NzBadgeModule,
    // NzRadioModule,
    // NzDropDownModule,
    // NzListModule,
    // NzDrawerModule,
    // NzDividerModule,
    // NzSwitchModule,
    // NzInputModule,
    // NzButtonModule,
    AntDesignModule
]
@NgModule({
    exports: [
        CommonModule,
        HeaderComponent,
        SearchComponent,
        QuickViewComponent,
        SideNavComponent,
        SideNavDirective,
        FooterComponent,
        CommonHeaderComponent,
        HeaderOneComponent,
        WelcomeModalComponent,
        NgxSpinnerComponent,
        OTPComponent
    ],
    imports: [
        RouterModule,
        CommonModule,
        SharedModule,
        ...antdModule
    ],
    declarations: [
        HeaderComponent,
        SearchComponent,
        QuickViewComponent,
        SideNavComponent,
        SideNavDirective,
        FooterComponent,
        CommonHeaderComponent,
        HeaderOneComponent,
        WelcomeModalComponent,
        NgxSpinnerComponent,
        OTPComponent
    ],
    providers: [ 
        ThemeConstantService
    ],
    schemas: [CUSTOM_ELEMENTS_SCHEMA]
})

export class TemplateModule { }
