export class ApiEndPoints {
    // public static AWS_COGNITO_URL = 'http://15.207.215.148:3030';
    
    // public static SPRING_URL = "http://192.168.2.103:9095";
}