import { Injectable } from '@angular/core';
@Injectable({
    providedIn: 'root'
})
export class SharedService {

    milestoneData: any = [];

    addMilestoneData :any = [];

    workPackagesDetailsShared: any = [];

    workpackageData: any = [];

    freelancerDetails : any = [];

    isRecommendations : boolean = false;

    stomplClient: any;

    onProfileScreen: boolean = false;

    freeProfiledata:Object = null

    uploadfreeProfiledata:Object = null

    employerProfiledata:Object = null

    empuploadProfiledata:Object = null

    showEmpWelcomeModal : boolean = false;

    showFreeWelcomeModal : boolean = false;

    constructor() { }
}
