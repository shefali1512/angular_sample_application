import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { environment } from '../../environments/environment';
import { BehaviorSubject } from 'rxjs';
@Injectable({
    providedIn: 'root'
})
export class MasterService {

    SPRING_SERVER_URL: string = '';

    headers: any = null;
    token: any;


    showChatUserList = new BehaviorSubject(false);

    constructor(private http: HttpClient) {
        this.SPRING_SERVER_URL = environment.SPRING_SERVER_URL;
        this.token = sessionStorage.getItem("jwtToken");

    }

    getHeader() {
        this.headers = new HttpHeaders({
            'Access-Control-Allow-Origin': '*',
            'Content-Type': 'application/json',
            'Access-Control-Allow-Methods': ['GET', 'POST', 'PUT', 'DELETE', 'PATCH']
        })
        return this.headers;
    }

    /*================================= Get Master Countries =============================*/
    getMasterCountry() {
        this.headers = this.getHeader();
        return this.http.get(this.SPRING_SERVER_URL + 'master/countries', { headers: this.headers });
    }
    /*=================================  Get Master Countries =============================*/

    /*================================= Get Master state =============================*/
    getMasterState(countryId: any) {
        this.headers = this.getHeader();
        return this.http.get(this.SPRING_SERVER_URL + `master/states/${countryId}`, { headers: this.headers });
    }
    /*=================================  Get Master Countries =============================*/

    /*================================= Get Master Cities =============================*/
    getMasterCities(stateId: any) {
        this.headers = this.getHeader();
        return this.http.get(this.SPRING_SERVER_URL + `master/cities/${stateId}`, { headers: this.headers });
    }
    /*=================================  Get Master Cities =============================*/

    /*================================= Get Master Currancy =============================*/
    getMasterCurrancy() {
        this.headers = this.getHeader();
        return this.http.get(this.SPRING_SERVER_URL + 'master/currencies', { headers: this.headers });
    }
    /*=================================  Get Master Currancy =============================*/

    /*================================= Get Master Skill Categories =============================*/
    getMasterSkillCategories() {
        this.headers = this.getHeader();
        return this.http.get(this.SPRING_SERVER_URL + 'master/skills/categories');
    }
    /*=================================  Get Master Skill Categories =============================*/

    /*================================= Get Master Skill Sub-Categories =============================*/
    getMasterSkillSubCategories(categoryId: any) {
        this.headers = this.getHeader();
        return this.http.get(this.SPRING_SERVER_URL + `master/skills/subCategories/${categoryId}`);
    }

    /*=================================  Get Master Skill Sub-Categories =============================*/
    getMasterSkills(subCategoryId: any) {
        this.headers = this.getHeader();
        return this.http.get(this.SPRING_SERVER_URL + `master/skills/${subCategoryId}`);
    }

    /*=================================  Set user Chat List Mode =============================*/
    setUserChatListMode(value) {
        this.showChatUserList.next(value);
    }


    /*=================================  Get Preset Screening Questions =============================*/
    getMasterScreeningQuestions() {
        this.headers = this.getHeader();
        return this.http.get(this.SPRING_SERVER_URL + `master/screeningQuestions`).toPromise();
    }

    /*================================= GET setting parameter =============================*/

    getSettingParameterByCountryAndParameter(countryId: any, parameter: any) {
        return this.http.get(this.SPRING_SERVER_URL + `master/settings/${countryId}/${parameter}`).toPromise();
    }

    /*====================== Service for updateEmployerProfilePhoto Details ===================*/
    saveBlockchainTimeline(requestData: any) {
        this.headers = this.getHeader();
        return this.http.post(this.SPRING_SERVER_URL + `timeline/onboard`, requestData, { headers: this.headers });
    }

    getMasterIdentitydocumentstypes() {
        this.headers = this.getHeader();
        return this.http.get(this.SPRING_SERVER_URL + `master/identityDocumentTypes`, { headers: this.headers })
    }


    keyPress(event: any) {
        const pattern = /[0-9\+\-\ ]/;

        let inputChar = String.fromCharCode(event.charCode);
        if (pattern.test(inputChar)) {
            event.preventDefault();
        }
    }

    numericOnly(event): boolean {
        let patt = /^([0-9])$/;
        let result = patt.test(event.key);
        return result;
    }

    checkIsNumber(evt) {
        var keyCode = (evt.which) ? evt.which : evt.keyCode
        if (keyCode > 47 && keyCode < 58 || keyCode == 8 || keyCode == 9) {
            return true;
        }
        else {
            evt.preventDefault();
            return false;
        }
    }
}
