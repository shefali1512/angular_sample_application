import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { environment } from 'src/environments/environment';

@Injectable({
  providedIn: 'root'
})
export class OtpVerficationService {

  SPRING_SERVER_URL: string = '';

  headers: any = null;

  token: any = null;

  getHeader() {
    this.headers = new HttpHeaders({
      'Access-Control-Allow-Origin': '*',
      'Content-Type': 'application/json',
      'Access-Control-Allow-Methods': ['GET', 'POST', 'PUT', 'DELETE', 'PATCH'],
      // 'Authorization': 'Bearer ' + this.token,
    })
    return this.headers;
  }

  constructor(private http: HttpClient) {
    this.SPRING_SERVER_URL = environment.SPRING_SERVER_URL;
  }

  
 /*====================== Service for send otp and resend otp Details ===================*/
 sendOTP(otpsendData: any) {
  this.headers = this.getHeader();
  return this.http.post(this.SPRING_SERVER_URL + 'generateOtp', otpsendData , { headers: this.headers });
}
/*====================== Service for send otp and resend otp Details ===================*/

  
 /*====================== Service for otpVerifyData o Details ===================*/
 verifyOTP(otpVerifyData: any) {
  this.headers = this.getHeader();
  return this.http.post(this.SPRING_SERVER_URL + 'validateOtp', otpVerifyData , { headers: this.headers });
}
/*====================== Service for send otp and resend otp Details ===================*/



}
