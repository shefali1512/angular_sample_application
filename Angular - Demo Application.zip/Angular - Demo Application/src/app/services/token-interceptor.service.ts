import { Injectable, Injector } from '@angular/core';
import { HttpRequest, HttpHandler, HttpEvent, HttpInterceptor } from '@angular/common/http';
import { Observable, Subject, Subscription, timer } from 'rxjs';
import { AuthenticationService } from './authentication.service';

@Injectable()
export class TokenInterceptorService implements HttpInterceptor {

    isRefreshedToken: boolean = false;
    constructor(private injector: Injector, private authenticationService: AuthenticationService) { }

    intercept(request: HttpRequest<any>, next: HttpHandler): Observable<HttpEvent<any>> {
        let authToken: any = sessionStorage.getItem("jwtToken");
        if (authToken) {
            if (!this.isRefreshedToken) {
                let jwtData = authToken.split('.')[1]
                let decodedJwtJsonData = window.atob(jwtData);
                let decodedJwtData = JSON.parse(decodedJwtJsonData)
                let date2 = new Date();
                let date1 = new Date(0);
                date1.setUTCSeconds(decodedJwtData.exp);
                if (date2.getTime() >= date1.getTime()) {
                    this.isRefreshedToken = true;
                    this.authenticationService.refreshJWTToken().then((refreshTokenRes: any) => {
                    });
                }
            }

        }
        let tokanizedRequest = request.clone({
            setHeaders: {
                Authorization: `Bearer ${authToken}`
            }
        });
        return next.handle(tokanizedRequest);
    }
}