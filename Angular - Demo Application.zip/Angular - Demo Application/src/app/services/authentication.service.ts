import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders ,HttpParams} from '@angular/common/http';
import { throwError } from 'rxjs';
import { map } from 'rxjs/operators';
import { Router } from '@angular/router';
import { environment } from 'src/environments/environment';

const httpOptions = {
    headers: new HttpHeaders({
        'Content-Type': 'application/json',
        'Access-Control-Allow-Headers': 'Content-Type',
        'Access-Control-Allow-Methods': '*',
        'Access-Control-Allow-Origin': '*'
    })
};
@Injectable({
    providedIn: 'root'
})

export class AuthenticationService {

    token: string = null;

    AWS_COGNITO_URL: string = null;

    SPRING_SERVER_URL: string = null;

    constructor(private http: HttpClient, private router: Router) {
        this.AWS_COGNITO_URL = environment.AWS_COGNITO_URL;
        this.SPRING_SERVER_URL = environment.SPRING_SERVER_URL;
        this.token = localStorage.getItem("access_token");
    }

    //Signup Node-Cognito
    async signUpUserCognito(userData: any) {
        try {
            let res: any = await this.http.post(this.AWS_COGNITO_URL + '/signup', userData).toPromise();
            return res;
        } catch (error) {
            await this.handleError(error);
        }
    }

    //Signup Spring-DB 
    async signUpUserDb(userData: any) {
        try {
            let res = await this.http.post(this.SPRING_SERVER_URL + 'auths/signup', userData, httpOptions).toPromise();
            return res;
        } catch (error) {
            this.handleError(error);
        }
    }

    // reset password aws-cognito
    async resetPassword(pwdData: any) {
        try {
            let res = await this.http.post(this.AWS_COGNITO_URL + '/reset-password', pwdData).toPromise();
            return res;
        } catch (error) {
            await this.handleError(error);
        }
    }

    // reset password info
    async resetPasswordInfo(email:any,password:any){
             let response = this.http.patch(this.SPRING_SERVER_URL + `auths/resetPassword/${email}/${password}`,httpOptions).toPromise();
             return response;
    }

    async sendResetPwdDetails(data: any) {
        try {
            let res = await this.http.post(this.AWS_COGNITO_URL + '/reset-pwd-details', data).toPromise();
            return res;
        } catch (error) {
            await this.handleError(error);
        }
    }

    // Login AWS call 
    userLoginCognito(loginPayload): any {
        return this.http.post<{ response: string }>(this.AWS_COGNITO_URL + '/login', loginPayload)
            .pipe(map(result => {
                return result;
            }));
    }

    // SignIn backend call
    async userLogInDb(data: any) {
        try {
            let res: any = await this.http.patch(this.SPRING_SERVER_URL + 'auths/signin/' + data + "/", httpOptions).toPromise();
            return res;
        } catch (error) {
            return error;
        }
    }


    // SignIn backend call
    async getJWTToken(data: any) {
        try {
            let res: any = await this.http.post(this.SPRING_SERVER_URL + 'auths/authenticate/', data, httpOptions).toPromise();
            return res;
        } catch (error) {
            return error;
        }
    }

    async refreshJWTToken() {
        let httpOptions = {
            headers: new HttpHeaders({
                'Content-Type': 'application/json',
                'Access-Control-Allow-Headers': 'Content-Type',
                'Access-Control-Allow-Methods': '*',
                'Access-Control-Allow-Origin': '*',
                'isRefreshToken' : 'true'
            })
        };
        try {
            let res: any = await this.http.get(this.SPRING_SERVER_URL + 'auths/refreshToken', httpOptions).toPromise();
            return res;
        } catch (error) {
            return error;
        }
    }


    // Error Handler
    async handleError(error: any) {
        let errorMessage = '';
        if (error.error instanceof ErrorEvent) {
            // client-side error
            errorMessage = `Client Error: ${error.error.message}`;
        } else {
            // server-side error
            errorMessage = `Server Error Code: ${error.status}\nMessage: ${error.message}`;
        }
        throwError(errorMessage)
    }

    //to check if email already exist - returns true or false
    async checkifEmailAlreadyExist(emailId: any) {
        try {
            let res = await this.http.get(this.SPRING_SERVER_URL + 'auths/checkIfEmailExist/' + emailId + '/', httpOptions).toPromise();
            return res;
        } catch (error) {
            this.handleError(error);
        }
    }

    setToken(token) {
        localStorage.setItem('token', token);
    }

    getToken() {
        return localStorage.getItem('token');
    }

    /*================================= Service for remove token =============================*/
    removeToken() {
        localStorage.clear();
        localStorage.removeItem('token');
        this.router.navigate(['/sign-in']);
    }

    isLoggedIn() {
        return !!localStorage.getItem("token");
    }

    async updateEmailStatus(userId) {
        try {
            let res = await this.http.patch(this.SPRING_SERVER_URL + 'auths/emailVerified/' + userId, httpOptions).toPromise();
            return res;
        } catch (error) {
            this.handleError(error);
        }
    }

    async signOut(userId) {
        try {
            let res = await this.http.patch(this.SPRING_SERVER_URL + 'auths/signout/' + userId, httpOptions).toPromise();
            return res;
        } catch (error) {
            this.handleError(error);
        }
    }
}
